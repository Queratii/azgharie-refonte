# CLAUDE.md — Refonte Azgharie

Contexte de travail pour Claude (Claude Code, Cowork…). À lire avant toute modification.

## Le projet

Refonte **uniquement visuelle** du site communautaire [azgharie.net](https://www.azgharie.net) (WordPress, thème Astra), pour le streamer **Azghaaar** et sa communauté « l'Azgharie » (Twitch, YouTube, Discord depuis 2017).

- Commanditaire : Joseph (Halpades). Le fondateur aime le **bleu** ; animations **sobres** ; le rendu ne doit **pas ressembler à un site généré par IA**.
- Livrable actuel : site **HTML/CSS statique autonome**, destiné à être intégré ensuite par un développeur dans le WordPress existant.
- Concept : **« L'Atlas d'Azgharie »**. L'Azgharie est traitée comme un pays : carte quadrillée, jeux = **territoires codés** (TER·01…06), **passeport** azgharien (CTA Discord), agenda en **tableau des départs** d'aéroport, **cocarde** (emblème rond bleu/blanc/nuit, clin d'œil aux cocardes d'aviation).

## En ligne

| Quoi | Où |
|---|---|
| Site publié (GitHub Pages) | https://queratii.github.io/azgharie-refonte/ |
| Dépôt | https://github.com/Queratii/azgharie-refonte (public, branche `main`, Pages depuis `/ (root)`) |
| Maquettes (canvas Design, privé) | https://claude.ai/artifact/C6qLMU6rxoqaSZGzbti6pW |
| Aperçu navigable (artifact, privé) | https://claude.ai/artifact/TnS1D19bpAP99oySu6Zun3 |
| Copie locale | `Documents/azgharie-refonte` (PC « surfacepro-lucas ») |

Toutes les pages portent `<meta name="robots" content="noindex, nofollow">` (choix du commanditaire : maquette publique mais non indexée).

## Structure

```
index.html, agenda.html, elite-dangerous.html, flight-simulator.html, f1.html,
no-mans-sky.html, planet-coaster-2.html, multigaming.html, contacts.html
assets/css/style.css   ← feuille unique, jetons dans :root
assets/js/main.js      ← menu mobile, sous-menu Territoires, filtres agenda
assets/img/cocarde.svg ← favicon / emblème
README.md              ← guide d'intégration pour le développeur
.claude/               ← contexte détaillé + générateur (voir ci-dessous)
```

## Règles à respecter

- **Bleu dominant.** Palette : voir `.claude/context/design-system.md`. L'orange `--signal` est réservé au « en direct » et à l'état actif, nulle part ailleurs.
- **Animations sobres** : survol 200 ms (léger soulèvement), pulsation lente du point « direct ». Rien d'autre. Toujours respecter `prefers-reduced-motion`.
- **Polices** : Archivo (titres en `font-stretch: 125%`, poids 800 ; textes), IBM Plex Mono (codes, horaires, étiquettes). Pas d'Inter/Roboto/Space Grotesk, pas d'emoji, pas de dégradés décoratifs.
- **Contenus réels uniquement** (repris du site actuel). Ce qui manque reste un emplacement `[…]` hachuré (`.ph`) avec un commentaire `<!-- IMAGE : … -->` / `<!-- DONNÉES : … -->`. Ne pas inventer de chiffres.
- **Responsive** : aucune barre de défilement horizontale à 390 px ; menu burger < 1080 px ; tableaux de l'agenda en fiches < 760 px.
- Liens externes : `target="_blank" rel="noopener"`.
- Langue : français, ton chaleureux (« bienveillance et bonne humeur »).

## Modifier le site

Les pages HTML sont **générées** par les scripts Python de `.claude/build/` (en-tête, bandeau « prochain direct » et pied de page sont communs). Pour un changement durable :

1. modifier `layout.py` (gabarit commun, URL, liste des territoires) ou `pages_a.py` / `pages_b.py` (contenu des pages) ;
2. régénérer depuis la racine du dépôt : `python3 .claude/build/build.py .` ;
3. le CSS et le JS se modifient directement dans `assets/`.

Une retouche ponctuelle peut aussi se faire directement dans le HTML, mais elle sera écrasée à la prochaine régénération : la reporter dans les scripts.

Après un `git push` sur `main`, GitHub Pages republie en 1 à 2 minutes.

## À faire / à confirmer

- Saison F1 : le site actuel dit « saison 7 en cours », l'agenda annonce la **saison 8 (F1 26) au 16 octobre** → la maquette affiche la saison 8 ; le règlement pointe encore `saison7.pdf`.
- Brancher les vraies images, le flux YouTube, l'agenda, le flux FSHub, la carte Leaflet du World Tour (liste complète dans `README.md`).
- Bandeau « prochain direct » et données datées (agenda, World Tour) figés au **9 octobre 2026**.
- Bugs du site actuel à signaler : lien Discord en `tel:` et extension Firefox en `mailto:` dans le pied de page ; section « Mes dernières vidéos » vide sur l'accueil.

Pour l'historique complet des échanges et décisions : `.claude/context/historique.md`. Pour les données brutes récupérées sur le site : `.claude/context/contenus.md`.
