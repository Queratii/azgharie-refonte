# Historique du projet — Refonte Azgharie

Résumé chronologique des échanges entre Joseph et Claude (session Cowork, du 9 au 12 octobre 2026).

## 1. Demande initiale (9 oct.)

> Analyser www.azgharie.net et proposer des ébauches d'amélioration. Refonte **visuelle uniquement**. Le fondateur aime beaucoup le **bleu**. Rester **sobre sur les animations**. Utiliser Claude in Chrome. **Ne pas ressembler à n'importe quel site IA**, faire quelque chose d'original. Découvrir d'abord le site et utiliser ses informations pour coller à la communauté.

## 2. Analyse du site existant

Site WordPress (thème Astra 3.3), polices Noto Sans + Montserrat, menu : Accueil, Agenda, Elite Dangerous (Squadron, Vidéos ED, BD), Microsoft Flight Simulator (World Tour 2, Azgharie Airlines, Mods & logiciels…), No Man's Sky, F1, Multigaming, Planet Coaster 2, Contacts.

Constats :
- **Identité incohérente** : les pages MSFS / World Tour 2 avaient déjà des cartes modernes, le reste (accueil, ED, Multigaming) restait sur le gabarit Astra d'origine (bandeau photo + titre centré + texte brut).
- **Accueil plat** : un bloc de texte, liens multicolores (violet Twitch, rouge YouTube, bleu Discord), section « Mes dernières vidéos » **vide**.
- **Logo** : bouton « play » bleu sur fond gris, « AZGHAAAR — Twitch & YouTube » ; lié à la chaîne plus qu'à la communauté.
- **Bugs** : dans le pied de page, Discord en `tel:http://discord.gg/Azgharie`, extension Firefox en `mailto:https://addons.mozilla.org/…`.
- La page Planet Coaster 2 (NexChesterLand) a sa propre identité de parc fictif (billetterie, hôtels…) : à conserver, la refonte n'en fait qu'une page d'entrée.
- La page NMS est une image (carte de guilde avec glyphes du portail).

## 3. Concept retenu : « L'Atlas d'Azgharie »

Point de départ : le site dit « Bienvenue **en** Azgharie », comme un pays. D'où :
- jeux = **territoires** codés TER·01 à TER·06, sur un fond **quadrillé** façon carte ;
- **passeport azgharien** (devise, territoires, tampon « Lalande 10797 », ligne MRZ) comme CTA vers le Discord ;
- agenda en **tableau des départs** d'aéroport (clin d'œil à MSFS), avec codes de territoire ;
- **cocarde** bleu/blanc/nuit comme emblème ;
- codes OACI (LLIB → LLHA…) et coordonnées comme détails propres au sujet ;
- bleu partout (6 nuances dérivées du bleu du logo), un seul orange « signal » pour le direct.

## 4. Maquettes (canvas Design)

Canvas « Refonte Azgharie » : https://claude.ai/artifact/C6qLMU6rxoqaSZGzbti6pW
Planches : Accueil (1440), Agenda — tableau des départs (interactif, filtres), Territoire Elite Dangerous, Accueil mobile (390), Système visuel.

## 5. Passage en site web (9 oct.)

Joseph : « Quand tu auras fini avec les maquettes je te laisserai concrétiser le tout en les mettant sous forme de site web. »
Question posée : thème WordPress ou HTML/CSS autonome ? → **« un site HTML/CSS autonome qu'un développeur intégrera ensuite »**.

Réalisé :
- 9 pages (les 3 maquettées + MSFS, F1, NMS, Planet Coaster 2, Multigaming, Contacts), contenus récupérés sur le site actuel (textes, chiffres World Tour, vols FSHub, playlists F1, liens de contact) ;
- CSS unique à jetons, JS minimal (menu mobile, sous-menu, filtres agenda), favicon cocarde ;
- tests Playwright desktop 1440 / mobile 390 : pas de débordement horizontal, liens internes valides, filtres et menus fonctionnels ;
- corrections après tests : tampon du passeport qui masquait du texte, tuiles illisibles sur fond quadrillé, tableau FSHub en blanc sur blanc, cartes Multigaming tronquées sur mobile ;
- zip `azgharie-site.zip` + aperçu artifact : https://claude.ai/artifact/TnS1D19bpAP99oySu6Zun3

## 6. Publication GitHub (9 oct.)

Joseph : « J'ai GitHub ouvert et connecté sur Chrome, mets-moi le projet sur GitHub et rends le site accessible via mon GitHub. »
Choix : dépôt **azgharie-refonte**, **public + non indexé** (`noindex` sur chaque page, pour éviter la confusion avec azgharie.net).

Réalisé via Chrome (compte **Queratii**) :
- création du dépôt, envoi des fichiers par l'interface « Upload files » (racine, puis `assets/css`, `assets/js`, `assets/img`) ;
- GitHub Pages activé (Deploy from a branch → `main` / root) ;
- description du dépôt + lien Pages dans « About » ;
- site vérifié en ligne avec les vraies polices : https://queratii.github.io/azgharie-refonte/
- copie locale des fichiers dans `Documents/azgharie-refonte`.

Note technique : `gh` n'est pas authentifié dans l'environnement cloud ; l'envoi passe par l'upload web de GitHub dans Chrome (seuls les fichiers du dossier de travail de la session sont acceptés par l'outil d'upload).

## 7. Contexte (12 oct.)

Joseph demande le dossier `.claude` pour garder le contexte → création de `CLAUDE.md` + `.claude/` (ce dossier).
