# Système visuel — L'Atlas d'Azgharie

Source de vérité : `assets/css/style.css` (bloc `:root`). Ce fichier en est le résumé commenté.

## Couleurs

| Jeton | Valeur | Usage |
|---|---|---|
| `--espace` | `#050E1F` | fonds « spatiaux » (Elite Dangerous, NMS) |
| `--nuit-profonde` | `#07142A` | bandeau « prochain direct », pied de page, tableaux |
| `--nuit` | `#0B1B33` | fond sombre principal, texte sur fond clair |
| `--encre` | `#12305A` | panneaux, en-têtes de jour, cartes sombres |
| `--azur-fonce` | `#1F5F96` | survol des boutons |
| `--azur` | `#2A72B0` | boutons, liens — le bleu du logo Azghaaar |
| `--azur-vif` | `#2F7FC1` | filets, cocarde, contours des tags |
| `--ciel` | `#8EC3EE` | accents et étiquettes sur fond sombre |
| `--brume` | `#C9DDF0` | texte secondaire sur fond sombre |
| `--passeport` | `#E3EDF7` | cartes claires sur fond sombre (passeport) |
| `--papier` | `#EEF3F8` | fond clair |
| `--grille` | `#DCE6F1` | quadrillage de carte |
| `--trait` | `#C9D8E8` | bordures |
| `--texte-2` | `#2B3F5C` | texte secondaire sur clair |
| `--label` | `#2A6296` | étiquettes mono sur clair |
| `--signal` / `--signal-clair` | `#F2994A` / `#F2B27A` | **uniquement** « en direct », « ce soir », onglet actif |

Le site a un seul rendu volontaire (alternance de sections claires et sombres), pas de mode sombre séparé.

## Typographie

- **Archivo** (Google Fonts, axe de largeur 62–125) : titres en `font-stretch: 125%`, poids 800, interlignage serré ; textes courants en largeur normale.
- **IBM Plex Mono** : codes (TER·01, OACI, F1/ED/MSFS), horaires, étiquettes en capitales espacées (`letter-spacing: .14em`).
- Échelle : `--t-xs` 12 → `--t-4xl` (≈ 76 px, fluide via `clamp`).

## Motifs propres au sujet

- **Quadrillage de carte** : `.grid-paper` (clair) et `.grid-night` (sombre), maille 48 px (32 px sur mobile).
- **Lignes de niveau** (ellipses SVG) dans le héros d'accueil ; **orbites + planète** sur les pages spatiales ; **champ d'étoiles** `.stars`.
- **Cocarde** `.cocarde` (dégradé radial à arrêts nets : nuit / blanc / azur).
- **Passeport** `.passport` (bandeau encre, champs mono, ligne MRZ, tampon rond incliné `.stamp`).
- **Tableau des départs** `.board` (+ `.board--agenda`), lignes `.board__row`, jours `.board__day`, `.tag` pour le code du territoire, `.channel` LIVE/REPLAY.
- **Itinéraire** `.route` (rail pointillé + codes OACI).
- **Fiche** `.factsheet` (paires étiquette/valeur, ex. fiche du squadron).
- **Territoires** `.territory` (`--wide` avec image de couverture, `--dark` pour Multigaming).
- **Emplacements à remplacer** `.ph` (hachures bleues + libellé `[…]`).

## Mouvement

- Survol : `translateY(-1px)` sur boutons, `-3px` + ombre-onglet azur (`0 10px 0 -4px`) sur cartes. 200–250 ms.
- Pulsation lente (2,4 s) du point `.live-dot`.
- Tout est coupé sous `prefers-reduced-motion: reduce`.

## Responsive

- Gouttière `clamp(16px, 4vw, 32px)`, conteneur 1280 px.
- < 1080 px : navigation en menu burger (`.nav-toggle`, `#site-nav.is-open`).
- < 760 px : `.board` passe en fiches empilées ; statistiques en 2 colonnes.
- < 640 px : passeport réduit, boutons du héros en pleine largeur.

## À éviter

Inter / Roboto / Space Grotesk, emoji, dégradés violets, cartes avec barre latérale colorée, tout centré, animations au scroll, couleurs hors palette.
