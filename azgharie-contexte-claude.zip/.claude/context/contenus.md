# Contenus récupérés sur azgharie.net (relevé du 9 octobre 2026)

Données réelles utilisées dans la refonte. À mettre à jour à la source (WordPress, agenda, Google Sheet du World Tour, FSHub) lors de l'intégration.

## Communauté

- Azghaaar partage sa passion des jeux vidéo depuis **2017** sur Twitch, YouTube & Discord. La communauté s'appelle **l'Azgharie**.
- Partenaire **Twitch**, **Discord** & **Elite Dangerous**.
- Devise : « Un seul mot d'ordre : la bienveillance et la bonne humeur ! » — signature « Azghaaar ».

## Liens

| Service | URL |
|---|---|
| Twitch | https://www.twitch.tv/azghaaar |
| YouTube | https://www.youtube.com/@azghaaar (ancienne forme : /c/Azghaaar) |
| Discord | https://discord.gg/azgharie |
| Instagram | https://www.instagram.com/azghaaar/ |
| X / Twitter | https://twitter.com/AzghaaarGaming |
| TikTok | https://www.tiktok.com/@azghaaar |
| Soutien (don) | https://donation.wizebot.tv/?azghaaar |
| Extension Firefox | https://addons.mozilla.org/fr/firefox/addon/azghaaar-twitch/ |
| Extension Chrome | https://chrome.google.com/webstore/detail/azghaaar-twitch/cglokalcninalaelnfeonnijfehmpaop |
| FSHub (Azgharie Airlines) | https://fshub.io/airline/AZH/overview |
| Site de la ligue F1 | https://liguef1.azgharie.net/ |
| Règlement F1 saison 7 | https://fichiers.azgharie.net/f1/saison7.pdf |

Chaînes recommandées : Ashker NMS (YouTube UC7Ddg7m1SW06_zU0VdN5yVQ), No Man's Sky France (nms-france.fr), DafunkyHapax (twitch.tv/dafunkyhapax), Mr Yotsuya (twitch.tv/mr_yotsuya).

## Elite Dangerous (TER·01)

Squadron actif sur PC, PS4 & Xbox, basé dans le système **Lalande 10797**. Gameplay bienveillant, coopératif, sans prise de tête, essentiellement en **groupe privé**. Débutants ou expérimentés, jeunes ou vétérans, explorateurs ou combattants. Instructions sur le Discord. BD **Les Zarbros** (deux CMDR azghariens), planches sur Instagram (planche 1 : « Départ pour Cat's Paw Nebula »).

## Microsoft Flight Simulator (TER·02)

- **World Tour 1** : 329 étapes, 4 ans sur MSFS 2020, arrivée à Nouméa en octobre 2024.
- **World Tour 2** (MSFS 2024) : départ de Bruxelles, surtout VFR, parfois IFR. Compteurs : **92 étapes, 11 588 km, 95 aéroports, 12 pays, 551 jours**, moyenne 126 km.
  - Records : plus longue vol 74 Belgrade → Istanbul 813 km ; plus courte vol 31 Andorre → La Llagonne 49 km.
  - Avions : TBM930 87 étapes / 9 043 km ; A320 3 / 2 157 km ; G2 2 / 388 km.
  - Prochain rendez-vous : **dimanche 11 octobre, 20h**, 3 étapes, TBM930 :
    - Étape 93 Rosh Pina (LLIB) → Haïfa (LLHA), 105 km — Mer de Galilée, Tibériade, Mont Tabor, Nazareth
    - Étape 94 Haïfa (LLHA) → Tel Aviv (LLRS), 128 km — Mont Carmel, Césarée, Netanya, Tel Aviv/Jaffa
    - Étape 95 Tel Aviv (LLRS) → Massada (LLMZ), 147 km — Jérusalem, Bethléem, Hébron, Désert de Judée, Mer Morte, Massada
- **Azgharie Airlines** (FSHub), derniers vols du 08/10/2026 : LJBL → LIPB (Maskime, TBM-850, 01:02, 176 nm, −86 ft/m) ; LIPB → LSZS (Maskime, TBM-850, 00:22, 83 nm, −3 ft/m) ; LTFM → LFPG (Sachimic, B777-300ER, 02:55, 1259 nm, −265 ft/m).
- Rendez-vous communautaires : Vols IFR (projet en cours de reprise) ; « Où est Chouchou ? » (aidez-nous à transporter Chouchou).
- Archives : World Tour 1, Azgharie Airport, JoinFS (serveur privé), anciennes livrées & mods.
- Sous-pages conservées : `/microsoft-flight-simulator/livrees-azgharie/`, `/mods-logiciels/`, `/azgharie-airlines/`, `/azgharie-world-tour-2/`.

## F1 — Ligue Azgharienne (TER·03)

Championnat sur les jeux F1, GP en direct sur Twitch **le vendredi à 20h**, replays YouTube. Saison 7 (F1 25) : 17 oct. → 12 juin. L'agenda annonce **Saison 8 (F1 26), GP de Monaco le 16 octobre**. Esprit : bienveillance, pas de tryhard, entraide, pas de drama ; « pas une ligue e-sport ». Présentation dans le salon Discord #nouveaux-pilotes.
Playlists : S2 F1 21 (2021/22) `PLDS-Dys8LzCU4_lEFjpvCzK_Ml9GEKHZi` · S3 F1 21 (2022) `PLDS-Dys8LzCUJ6BGiqDyu8xG6JvucrPWj` · S4 F1 22 (2022/23) `PLDS-Dys8LzCX_8GSsLqZnodJi0h-n8Zwi` · S5 F1 23 (2023/24) `PLDS-Dys8LzCWxwcxI-TrPc4wQF2Ox_WEq` · S6 F1 24 (2024/25) `PLDS-Dys8LzCUSNGzdZWUQHY_IbFEu2FEh`.

## No Man's Sky (TER·04)

Guilde **Azgharie**, système **Continia**, galaxie **Euclide**, coordonnées du portail en 12 glyphes (image sur la page actuelle). Directs le samedi 13h.

## Planet Coaster 2 — NexChesterLand (TER·05)

Parc d'attractions de la communauté (page actuelle : site de parc fictif avec Billetterie, Nos hôtels, Notre parc, Nos horaires, Infos pratiques). Ouverture « proche », billetterie disponible, réservations de séjour à venir, piscines/toboggans dans les hôtels du resort, ticket DUO.

## Multigaming (TER·06)

Serveur de jeu Azgharie (survie : 7 Days to Die, Ark, Valheim) ; Azghaaar partenaire des alphas de 7 Days to Die. Euro Truck / American Truck Simulator : entreprise virtuelle, livrées par LeDoc. Aussi : Sea of Thieves, Star Citizen, No Man's Sky… (agenda d'octobre : Planet Zoo 2, Star Wars: Galactic Racer).

## Agenda (octobre 2026)

| Date | Horaire | Programme | Type |
|---|---|---|---|
| ven. 9 | 17:00–17:30 | F1 25 — Course 20 | Replay |
| ven. 9 | 20:00–22:30 | F1 26 — Pré-saison · GP de Chine | Live |
| sam. 10 | 13:00–15:00 | No Man's Sky | Live |
| sam. 10 | 17:00–17:30 | Azgharie World Tour 2 — Étape 92 | Replay |
| dim. 11 | 13:00–15:00 | Elite Dangerous | Live |
| dim. 11 | 20:00–22:00 | MSFS 2024 — Azgharie World Tour 2 | Live |
| mar. 13 → jeu. 15 | 20:00–22:30 | Planet Zoo 2 (découverte le 13) | Live |
| ven. 16 | 20:00–22:30 | F1 26 — Saison 8 Ligue Azgharienne — GP de Monaco | Live |
| sam. 17 | 13:00–15:00 | No Man's Sky | Live |
| dim. 18 | 13:00–15:00 | Star Wars: Galactic Racer | Live |
| dim. 18 | 20:00–22:00 | MSFS 2024 — Azgharie World Tour 2 | Live |
| dim. 25 | 20:00–22:00 (supposé) | MSFS 2024 — Azgharie World Tour 2 | Live |
